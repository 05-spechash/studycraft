const CACHE='studycraft-v4';
const CORE=['./','./index.html','./studycraft-pro.js','./studycraft-manifest.webmanifest','./icon.svg','./icon-192.png','./icon-512.png'];
self.addEventListener('install',e=>{e.waitUntil(caches.open(CACHE).then(c=>Promise.all(CORE.map(u=>c.add(u).catch(()=>{})))).then(()=>self.skipWaiting()));});
self.addEventListener('activate',e=>{e.waitUntil(caches.keys().then(k=>Promise.all(k.filter(x=>x!==CACHE).map(x=>caches.delete(x)))).then(()=>self.clients.claim()));});
self.addEventListener('fetch',e=>{const r=e.request;if(r.method!=='GET')return;
e.respondWith(caches.open(CACHE).then(async c=>{const hit=await c.match(r);
const net=fetch(r).then(res=>{if(res&&(res.ok||res.type==='opaque'))c.put(r,res.clone());return res;}).catch(()=>null);
if(hit){net.catch(()=>{});return hit;}
const res=await net;if(res)return res;
return (r.mode==='navigate'&&await c.match('./index.html'))||Response.error();}));});
