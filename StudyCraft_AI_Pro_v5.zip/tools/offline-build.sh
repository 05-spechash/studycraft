#!/bin/sh
# Run on your own machine (needs internet + Node). Compiles Tailwind and prints SRI hashes.
npx tailwindcss@3.4.17 -i /dev/stdin -o tailwind.css --content ../index.html --minify <<'CSS'
@tailwind base;@tailwind components;@tailwind utilities;
CSS
for u in https://cdnjs.cloudflare.com/ajax/libs/pdf.js/3.11.174/pdf.min.js https://cdnjs.cloudflare.com/ajax/libs/jszip/3.10.1/jszip.min.js https://cdn.jsdelivr.net/npm/tesseract.js@5/dist/tesseract.min.js; do
 echo "$u sha384-$(curl -s $u | openssl dgst -sha384 -binary | openssl base64 -A)"; done
echo "Then replace the cdn.tailwindcss.com script tag with <link rel=stylesheet href=tailwind.css> and add integrity=\"...\" crossorigin=\"anonymous\" to the script tags."
